# Zola Huna · Portfolio

**Operations, Data & Systems Analyst** · E-commerce · Logistics & Aviation · Supply Chain · Retail · IT & Cybersecurity
🌐 **Website:** [zeehuna.github.io](https://zeehuna.github.io) · 💼 [LinkedIn](https://linkedin.com/in/zola-huna-aa7b51241) · ✉️ zolahuna.zo@gmail.com

> **Recruiters:** every project below has runnable code, data, charts and a README. Please look at the work.

12+ years across **Woolworths and DHL Express** (air-express hub at O.R. Tambo International Airport), now building hands-on in SQL, Python, Power BI, cybersecurity and IT, and founding **Open Scene**.

## Projects

| # | Project | Certificate / experience | Headline result | Stack |
|---|---|---|---|---|
| 01 | [Air Express Delivery Analytics](projects/01-air-express-delivery-analytics) | Google Data Analytics | Clearance time −47%, on-time +3.4 pts | SQL · Python |
| 02 | [E-commerce KPI Model](projects/02-powerbi-ecommerce-kpi-model) | Microsoft Power BI Advanced | 25 DAX measures validated in pandas | Power BI · DAX |
| 03 | [Security Log Analysis & IR](projects/03-security-log-incident-response) | Google Cybersecurity | 3/3 attacks detected, 0 false positives | Python · SQL · NIST |
| 04 | [SME Network Hardening](projects/04-sme-network-hardening) | Secure Infrastructure Technician | CIS maturity 37% → 90% | Bash · Linux |
| 05 | [Shipment Exception Bot](projects/05-shipment-exception-alert-bot) | 100 Days of Code: Python | 45-min manual check automated, 8/8 tests | Python · pytest |
| 06 | [Open Scene Web Prototype](projects/06-open-scene-web-prototype) | Full-Stack Web Development (2026) | Responsive site + JS calculator | HTML · CSS · JS |
| 07 | [IT Service Desk Analytics](projects/07-it-service-desk-analytics) | IT service management (ITIL 4) | ~R180k/yr SSPR business case | Python · ITIL 4 |
| 08 | [Open Scene Strategy & Model](projects/08-open-scene-platform-strategy) | Founder | Base-case break-even month 15 | Python · Excel |
| 09 | [Retail Inventory Optimisation](projects/09-retail-inventory-optimisation) | E-commerce retail (50k+ SKUs) | R3.5m excess stock identified | Python |

## Downloads
- [Career CV](downloads/Zola_Huna_Career_CV.pdf) · [IT, Data & Systems CV](downloads/Zola_Huna_IT_Data_Systems_CV.pdf)
- [Project Portfolio (PDF)](downloads/Zola_Huna_Project_Portfolio.pdf) · [Excel Workbook with pivot tables](downloads/Zola_Huna_Portfolio_Workbook.xlsx)

## Run any project
```bash
pip install -r requirements.txt
cd projects/01-air-express-delivery-analytics
python src/generate_data.py && python src/clean.py && python src/analyze.py
```

*All project data is synthetic (seeded scripts) and modelled on real-world patterns. No employer or customer data is used.*
