"""Shared chart style for all portfolio projects (teal / purple / charcoal palette)."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

HERE = os.path.dirname(os.path.abspath(__file__))
for f in ("Poppins-Regular", "Poppins-SemiBold", "Poppins-Bold"):
    p = os.path.join(HERE, f + ".ttf")
    if os.path.exists(p):
        fm.fontManager.addfont(p)

TEAL, TEAL2, PURPLE, INK, AMBER, CORAL, GREY = "#00788C", "#00BDCF", "#1D1160", "#1E2632", "#F2A541", "#E4572E", "#9AA5B1"
PALETTE = [TEAL, PURPLE, TEAL2, AMBER, CORAL, "#6C5CE7", GREY, "#2E86AB"]

plt.rcParams.update({
    "font.family": "Poppins" if any("Poppins" in f.name for f in fm.fontManager.ttflist) else "DejaVu Sans",
    "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#C5CCD3", "axes.labelcolor": "#3A4450", "xtick.color": "#3A4450", "ytick.color": "#3A4450",
    "axes.titleweight": "bold", "axes.titlesize": 12, "axes.titlecolor": INK, "axes.titlelocation": "left",
    "axes.grid": True, "grid.color": "#EEF1F4", "grid.linewidth": 0.8, "axes.axisbelow": True,
    "figure.facecolor": "white", "savefig.facecolor": "white", "legend.frameon": False,
})


def save(fig, path, dpi=200):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
