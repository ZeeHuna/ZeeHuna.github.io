# How to publish this site on GitHub Pages (10 minutes)

Your site will live at **https://zeehuna.github.io**.

## Option A: GitHub website (no coding)
1. Sign in to github.com as **ZeeHuna**.
2. Click **+** (top right) → **New repository**.
3. Repository name: **`ZeeHuna.github.io`** (exactly this). Set it to **Public**. Click **Create repository**.
4. On the new repo page, click **uploading an existing file**.
5. Unzip `ZeeHuna.github.io.zip` on your computer, open the folder, select **everything inside it** (index.html, README.md, projects, downloads, tools…) and drag it into the upload box. Wait for all files to finish uploading.
6. Click **Commit changes**.
7. Go to **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, branch **main**, folder **/ (root)**, then **Save**.
8. Wait 1–3 minutes and open **https://zeehuna.github.io**.

> The upload page accepts up to 100 files at a time. If it complains, upload the `projects` folder one project at a time.

## Option B: Git command line
```bash
cd ZeeHuna.github.io
git init
git add .
git commit -m "Portfolio: 9 projects, CVs, workbook and website"
git branch -M main
git remote add origin https://github.com/ZeeHuna/ZeeHuna.github.io.git
git push -u origin main
```
Then do step 7 above.

## After it's live
- Add **https://zeehuna.github.io** to your LinkedIn *Contact info → Website* and to the **Featured** section.
- Pin the repository on your GitHub profile.
- Your photo on the site comes from your GitHub profile picture automatically; if you don't have one, it shows a "ZH" monogram.
- To update a CV later, replace the file in `downloads/` with the same file name.
