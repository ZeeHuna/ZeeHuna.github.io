"""Open Scene — 36-month platform model, verification funnel and trust & safety KPIs.

Open Scene is a verified, 18+ South African creator-subscription platform (paid in rands)
that I am building. This model is a PLANNING TOOL: every input is an explicit assumption
in data/assumptions.csv, so investors or partners can change a number and re-run.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, CORAL, AMBER, GREY, INK  # noqa: E402

D = ROOT / "data"; O = ROOT / "outputs"; O.mkdir(exist_ok=True)
A = pd.read_csv(D / "assumptions.csv").set_index("key")["value"].astype(float)

def run(name, creator_growth, sub_growth_mult, churn):
    rows = []
    creators, fans = A.start_creators, A.start_subscribers
    cash = -A.launch_capex
    for m in range(1, 37):
        creators = creators * (1 + creator_growth * (0.97 ** m)) if m > 1 else creators
        new_fans = creators * A.new_fans_per_creator * sub_growth_mult * (0.985 ** m)
        fans = fans * (1 - churn) + new_fans
        gmv = fans * A.arpu_zar + fans * A.tip_rate * A.avg_tip_zar
        platform_rev = gmv * A.take_rate
        payment_fees = gmv * A.payment_fee_rate
        kyc = (new_fans + creators * creator_growth) * A.kyc_cost_per_user
        hosting = A.hosting_base + fans * A.hosting_per_user
        moderation = A.moderator_cost * max(1, np.ceil(creators / A.creators_per_moderator))
        opex = A.fixed_opex + hosting + moderation + kyc + payment_fees * 0     # fees passed through in GMV split
        ebitda = platform_rev - opex
        cash += ebitda
        rows.append(dict(scenario=name, month=m, creators=round(creators), subscribers=round(fans), gmv_zar=gmv,
                         platform_revenue_zar=platform_rev, creator_payouts_zar=gmv - platform_rev - payment_fees,
                         kyc_cost_zar=kyc, moderation_cost_zar=moderation, hosting_zar=hosting, opex_zar=opex,
                         ebitda_zar=ebitda, cumulative_cash_zar=cash))
    return pd.DataFrame(rows)

sc = pd.concat([run("Conservative", A.creator_growth_low, 0.75, A.churn_high),
                run("Base", A.creator_growth_base, 1.0, A.churn_base),
                run("Ambitious", A.creator_growth_high, 1.3, A.churn_low)])
sc.to_csv(O / "scenario_model_36m.csv", index=False)
summary = sc.groupby("scenario").apply(lambda g: pd.Series({
    "creators_m36": g.creators.iloc[-1], "subscribers_m36": g.subscribers.iloc[-1],
    "gmv_m36_zar": g.gmv_zar.iloc[-1], "platform_rev_y3_zar": g[g.month > 24].platform_revenue_zar.sum(),
    "creator_payouts_total_zar": g.creator_payouts_zar.sum(),
    "breakeven_month": int(g[g.ebitda_zar > 0].month.min()) if (g.ebitda_zar > 0).any() else None,
    "min_cash_zar": g.cumulative_cash_zar.min()}), include_groups=False).reindex(["Conservative", "Base", "Ambitious"])
summary.to_csv(O / "scenario_summary.csv")
print(summary.round(0).to_string())

# unit economics per paying subscriber per month (base)
arpu = A.arpu_zar + A.tip_rate * A.avg_tip_zar
ue = pd.DataFrame([("Fan spend (sub + tips)", arpu), ("Creator payout", -arpu * (1 - A.take_rate - A.payment_fee_rate)),
                   ("Payment processing", -arpu * A.payment_fee_rate), ("Hosting & streaming", -A.hosting_per_user),
                   ("KYC (amortised 12m)", -A.kyc_cost_per_user / 12)], columns=["item", "zar"])
ue.loc[len(ue)] = ["Platform contribution", ue.zar.sum()]
ue.to_csv(O / "unit_economics.csv", index=False)

# verification funnel (target design metrics)
funnel = pd.DataFrame({"stage": ["Visited sign-up", "Confirmed 18+ & accepted terms", "Uploaded SA ID / passport", "Live face match passed",
                                 "Account approved", "First subscription or tip"],
                       "users": [10000, 7400, 5200, 4700, 4550, 1600]})
funnel["step_conversion"] = funnel.users / funnel.users.shift(1)
funnel.to_csv(O / "verification_funnel.csv", index=False)

# charts
fig, ax = plt.subplots(figsize=(7, 3.6))
for n, c in [("Conservative", GREY), ("Base", TEAL), ("Ambitious", PURPLE)]:
    g = sc[sc.scenario == n]
    ax.plot(g.month, g.platform_revenue_zar / 1e6, color=c, lw=2.4, label=n)
ax.set_xlabel("Month"); ax.set_ylabel("R million / month"); ax.legend(fontsize=8.5)
ax.set_title("Open Scene platform revenue by scenario (36 months)")
save(fig, O / "chart_revenue_scenarios.png")

g = sc[sc.scenario == "Base"]
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar(g.month, g.ebitda_zar / 1e6, color=[CORAL if v < 0 else TEAL for v in g.ebitda_zar])
ax2 = ax.twinx(); ax2.grid(False); ax2.spines["top"].set_visible(False)
ax2.plot(g.month, g.cumulative_cash_zar / 1e6, color=PURPLE, lw=2.2); ax2.set_ylabel("Cumulative cash (R m)", color=PURPLE)
ax.axhline(0, color=GREY, lw=0.8); ax.set_ylabel("Monthly EBITDA (R m)"); ax.set_xlabel("Month")
be = summary.loc["Base", "breakeven_month"]
ax.set_title(f"Base case: EBITDA-positive from month {int(be)}; cash trough R{-summary.loc['Base','min_cash_zar']/1e6:.1f}m")
save(fig, O / "chart_base_ebitda_cash.png")

fig, ax = plt.subplots(figsize=(6.4, 3.6)); ax.grid(False)
w = funnel.users / funnel.users.max()
for i, (s, u, ww) in enumerate(zip(funnel.stage, funnel.users, w)):
    ax.barh(len(funnel) - i, ww, left=(1 - ww) / 2, color=[TEAL, TEAL, TEAL2, TEAL2, PURPLE, AMBER][i], height=0.78)
    ax.text(0.5, len(funnel) - i, f"{s}: {u:,}", ha="center", va="center", color="white" if i < 5 else INK, fontsize=8.3, fontweight="bold")
ax.axis("off"); ax.set_title("Verified-onboarding funnel (design targets)")
save(fig, O / "chart_verification_funnel.png")

fig, ax = plt.subplots(figsize=(6.4, 3.4))
vals = ue.zar.values; cum = np.concatenate([[0], np.cumsum(vals[:-1])])
colors = [TEAL] + [CORAL] * (len(vals) - 2) + [PURPLE]
for i, (v, c0) in enumerate(zip(vals, cum)):
    bottom = 0 if i in (0, len(vals) - 1) else c0 + min(v, 0)
    ax.bar(i, abs(v), bottom=bottom, color=colors[i]); ax.text(i, bottom + abs(v) + 2, (f"R{v:,.0f}" if v >= 0 else f"-R{-v:,.0f}"), ha="center", fontsize=8)
ax.set_xticks(range(len(vals))); ax.set_xticklabels([x.replace(" (", "\n(") for x in ue.item], fontsize=7.5)
ax.set_title("Unit economics per paying fan per month (base case)")
save(fig, O / "chart_unit_economics.png")
print(ue.round(2).to_string(index=False))
