"""Generate a synthetic air-express shipment dataset (Jan-Jun 2026).

The data is SYNTHETIC. It is modelled on realistic air-express patterns
(hub mix, customs clearance, service levels) so the analysis can be shared
publicly without exposing any employer or customer data.
Deliberate quality issues (duplicates, blanks, inconsistent text) are
injected so the cleaning step has real work to do.
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(2026)
N = 24_000
OUT = Path(__file__).resolve().parents[1] / "data" / "raw_shipments.csv"

hubs = ["JNB", "CPT", "DUR", "PLZ", "BFN", "ELS"]
hub_w = [0.46, 0.22, 0.15, 0.07, 0.05, 0.05]
services = {"Express 9:00": 1, "Express 12:00": 1, "Express Worldwide": 2, "Economy Select": 4}
svc_w = [0.08, 0.17, 0.55, 0.20]
segments = ["E-commerce B2C", "B2B Account", "SME", "Healthcare"]
seg_w = [0.48, 0.30, 0.16, 0.06]
dest = ["UK & Europe", "North America", "Africa", "Asia Pacific", "Middle East", "Domestic"]
dest_w = [0.34, 0.20, 0.16, 0.14, 0.06, 0.10]
reasons = ["Customs documentation", "Incorrect address", "Consignee unavailable", "Flight capacity",
           "Weather", "Hub sort backlog", "Duties unpaid"]

dates = pd.to_datetime("2026-01-01") + pd.to_timedelta(rng.integers(0, 181, N), unit="D")
hub = rng.choice(hubs, N, p=hub_w)
svc = rng.choice(list(services), N, p=svc_w)
seg = rng.choice(segments, N, p=seg_w)
dst = rng.choice(dest, N, p=dest_w)
weight = np.round(rng.gamma(1.6, 3.2, N) + 0.2, 2)
customs = (dst != "Domestic") & (rng.random(N) < 0.92)

# clearance hours: longer for B2C e-com (more paperwork gaps) and in Q1 peak; improves after April (process change)
base_clear = rng.gamma(2.2, 4.0, N)
base_clear += np.where(seg == "E-commerce B2C", 6, 0) + np.where(dates.month <= 2, 4, 0)
base_clear *= np.where(dates.month >= 4, 0.72, 1.0)          # SOP + tracing automation introduced in April
clear_h = np.where(customs, np.round(base_clear, 1), 0.0)

promised = np.array([services[s] for s in svc]) + np.where(dst == "Domestic", 0, 1)
delay_prob = 0.02 + 0.035 * (clear_h / 6) + np.where(hub == "ELS", 0.05, 0) + np.where(seg == "E-commerce B2C", 0.03, 0)
late = rng.random(N) < np.clip(delay_prob, 0, 0.6)
actual = promised + np.where(late, rng.integers(1, 4, N), -(rng.random(N) < 0.15).astype(int))
actual = np.maximum(actual, 1)
reason = np.where(late, rng.choice(reasons, N, p=[0.31, 0.14, 0.17, 0.12, 0.05, 0.11, 0.10]), "")
cost = np.round(180 + weight * rng.uniform(38, 55, N) + np.where(svc == "Express 9:00", 420, 0) + np.where(dst == "Domestic", -120, 0), 2)
csat = np.clip(np.round(rng.normal(4.5, 0.5, N) - np.where(late, 1.3, 0)), 1, 5)

df = pd.DataFrame({
    "shipment_id": [f"AWB{7400000000 + i}" for i in range(N)],
    "booking_date": dates.strftime("%Y-%m-%d"),
    "origin_hub": hub, "destination_region": dst, "service": svc, "customer_segment": seg,
    "weight_kg": weight, "customs_required": np.where(customs, "Y", "N"), "clearance_hours": clear_h,
    "promised_days": promised, "actual_days": actual, "delay_reason": reason, "cost_zar": cost, "csat": csat,
})

# ---- inject realistic data-quality problems ----
dup = df.sample(180, random_state=1)
df = pd.concat([df, dup], ignore_index=True)
idx = df.sample(140, random_state=2).index
df.loc[idx, "origin_hub"] = df.loc[idx, "origin_hub"].str.lower() + " "
idx = df.sample(95, random_state=3).index
df.loc[idx, "csat"] = np.nan
idx = df.sample(60, random_state=4).index
df.loc[idx, "weight_kg"] = -1
idx = df.sample(40, random_state=5).index
df.loc[idx, "customer_segment"] = "ecommerce b2c"
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

OUT.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(OUT, index=False)
print(f"wrote {len(df):,} rows -> {OUT}")
