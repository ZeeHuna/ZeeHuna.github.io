"""ANALYZE + SHARE phases: run every query in sql/analysis.sql, save results and build charts."""
import re
import sqlite3
import sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, PURPLE, TEAL2, AMBER, CORAL, GREY, INK  # noqa: E402

df = pd.read_csv(ROOT / "data" / "clean_shipments.csv")
con = sqlite3.connect(":memory:")
df.to_sql("shipments", con, index=False)

sql = (ROOT / "sql" / "analysis.sql").read_text()
results = {}
for block in re.split(r"-- name: ", sql)[1:]:
    name, query = block.split("\n", 1)
    results[name.strip()] = pd.read_sql_query(query, con)
    results[name.strip()].to_csv(ROOT / "outputs" / f"q_{name.strip()}.csv", index=False)
    print(f"\n== {name.strip()} ==\n{results[name.strip()].to_string(index=False)}")

out = ROOT / "outputs"
m = results["monthly_trend"]
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar(m["month"].str[5:], m["avg_clearance_h"], color="#D8F3F6", edgecolor=TEAL, label="Avg customs clearance (h)")
ax.set_ylabel("Clearance hours")
ax2 = ax.twinx(); ax2.grid(False); ax2.spines["top"].set_visible(False)
ax2.plot(m["month"].str[5:], m["on_time_pct"], color=PURPLE, marker="o", lw=2.6, label="On-time %")
ax2.set_ylabel("On-time %", color=PURPLE); ax2.set_ylim(80, 100)
ax.axvline(2.5, color=CORAL, ls="--", lw=1.2); ax.text(2.55, ax.get_ylim()[1] * 0.92, "SOP + tracing automation live", color=CORAL, fontsize=8.5)
ax.set_title("Clearance time down, on-time delivery up after April process change")
save(fig, out / "chart_monthly_trend.png")

p = results["delay_pareto"]
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar(p["delay_reason"], p["late_shipments"], color=[TEAL if c <= 60 else GREY for c in p["cumulative_pct"]])
ax.set_xticks(range(len(p))); ax.set_xticklabels(p["delay_reason"], rotation=25, ha="right", fontsize=8.5)
ax2 = ax.twinx(); ax2.grid(False); ax2.spines["top"].set_visible(False)
ax2.plot(p["delay_reason"], p["cumulative_pct"], color=CORAL, marker="o"); ax2.set_ylim(0, 105); ax2.set_ylabel("Cumulative %")
ax.set_title("Delay Pareto: 3 causes drive ~60% of late shipments")
save(fig, out / "chart_delay_pareto.png")

h = results["hub_performance"].sort_values("on_time_pct")
fig, ax = plt.subplots(figsize=(6, 3.4))
b = ax.barh(h["origin_hub"], h["on_time_pct"], color=[CORAL if v == h["on_time_pct"].min() else TEAL for v in h["on_time_pct"]])
ax.bar_label(b, fmt="%.1f%%", padding=3, fontsize=8.5); ax.set_xlim(80, 100)
ax.set_title("On-time % by origin hub")
save(fig, out / "chart_hub_on_time.png")

c = results["clearance_impact"]
fig, ax = plt.subplots(figsize=(6, 3.4))
b = ax.bar(c["clearance_band"], c["on_time_pct"], color=[TEAL2, TEAL, TEAL, PURPLE, CORAL][: len(c)])
ax.bar_label(b, fmt="%.1f%%", padding=3, fontsize=8.5); ax.set_ylim(70, 100)
ax.set_title("Longer customs clearance = more late deliveries")
save(fig, out / "chart_clearance_vs_ontime.png")
print("\ncharts saved")
