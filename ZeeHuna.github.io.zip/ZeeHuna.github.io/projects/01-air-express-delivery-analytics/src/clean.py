"""PROCESS phase: clean the raw shipment file and log every change."""
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
raw = pd.read_csv(ROOT / "data" / "raw_shipments.csv")
log = []

def note(step, before, after):
    log.append({"step": step, "rows_before": before, "rows_after": after, "rows_affected": before - after})

n = len(raw)
df = raw.drop_duplicates(subset="shipment_id", keep="first")
note("Remove duplicate air waybills", n, len(df))

bad_case = (df["origin_hub"] != df["origin_hub"].str.strip().str.upper()).sum()
df["origin_hub"] = df["origin_hub"].str.strip().str.upper()
log.append({"step": "Standardise hub codes (trim + upper-case)", "rows_before": len(df), "rows_after": len(df), "rows_affected": int(bad_case)})

seg_fix = (df["customer_segment"] == "ecommerce b2c").sum()
df["customer_segment"] = df["customer_segment"].replace({"ecommerce b2c": "E-commerce B2C"})
log.append({"step": "Map inconsistent segment labels", "rows_before": len(df), "rows_after": len(df), "rows_affected": int(seg_fix)})

n = len(df)
df = df[df["weight_kg"] > 0]
note("Drop invalid weights (<= 0 kg)", n, len(df))

missing_csat = int(df["csat"].isna().sum())
log.append({"step": "Keep rows with blank CSAT (excluded only from CSAT metrics)", "rows_before": len(df), "rows_after": len(df), "rows_affected": missing_csat})

df["booking_date"] = pd.to_datetime(df["booking_date"])
df["month"] = df["booking_date"].dt.strftime("%Y-%m")
df["on_time"] = (df["actual_days"] <= df["promised_days"]).astype(int)
df["days_late"] = np.maximum(df["actual_days"] - df["promised_days"], 0)
df["delay_reason"] = df["delay_reason"].fillna("")

df.to_csv(ROOT / "data" / "clean_shipments.csv", index=False)
pd.DataFrame(log).to_csv(ROOT / "outputs" / "data_cleaning_log.csv", index=False)
print(pd.DataFrame(log).to_string(index=False))
print(f"clean rows: {len(df):,}")
