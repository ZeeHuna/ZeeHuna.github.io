-- ANALYZE phase: SQL run against the cleaned table `shipments` (SQLite dialect, portable to BigQuery / T-SQL)

-- name: kpi_overview
SELECT COUNT(*)                                   AS shipments,
       ROUND(100.0 * AVG(on_time), 1)             AS on_time_pct,
       ROUND(AVG(CASE WHEN customs_required = 'Y' THEN clearance_hours END), 1) AS avg_clearance_h,
       ROUND(AVG(csat), 2)                        AS avg_csat,
       ROUND(SUM(cost_zar) / 1e6, 2)              AS revenue_zar_m
FROM shipments;

-- name: monthly_trend
SELECT month,
       COUNT(*)                                   AS shipments,
       ROUND(100.0 * AVG(on_time), 1)             AS on_time_pct,
       ROUND(AVG(CASE WHEN customs_required = 'Y' THEN clearance_hours END), 1) AS avg_clearance_h
FROM shipments
GROUP BY month
ORDER BY month;

-- name: hub_performance
SELECT origin_hub,
       COUNT(*)                                   AS shipments,
       ROUND(100.0 * AVG(on_time), 1)             AS on_time_pct,
       ROUND(AVG(days_late), 2)                   AS avg_days_late,
       RANK() OVER (ORDER BY AVG(on_time) DESC)   AS on_time_rank
FROM shipments
GROUP BY origin_hub
ORDER BY on_time_pct DESC;

-- name: delay_pareto
WITH d AS (
    SELECT delay_reason, COUNT(*) AS late_shipments
    FROM shipments
    WHERE on_time = 0 AND delay_reason <> ''
    GROUP BY delay_reason
)
SELECT delay_reason,
       late_shipments,
       ROUND(100.0 * late_shipments / SUM(late_shipments) OVER (), 1) AS pct_of_delays,
       ROUND(100.0 * SUM(late_shipments) OVER (ORDER BY late_shipments DESC ROWS UNBOUNDED PRECEDING)
             / SUM(late_shipments) OVER (), 1)    AS cumulative_pct
FROM d
ORDER BY late_shipments DESC;

-- name: segment_service_matrix
SELECT customer_segment,
       service,
       COUNT(*)                                   AS shipments,
       ROUND(100.0 * AVG(on_time), 1)             AS on_time_pct,
       ROUND(AVG(csat), 2)                        AS avg_csat
FROM shipments
GROUP BY customer_segment, service
ORDER BY customer_segment, service;

-- name: clearance_impact
SELECT CASE WHEN clearance_hours = 0 THEN '0 (domestic)'
            WHEN clearance_hours < 8  THEN '< 8 h'
            WHEN clearance_hours < 16 THEN '8-16 h'
            WHEN clearance_hours < 24 THEN '16-24 h'
            ELSE '24 h +' END                     AS clearance_band,
       COUNT(*)                                   AS shipments,
       ROUND(100.0 * AVG(on_time), 1)             AS on_time_pct,
       ROUND(AVG(csat), 2)                        AS avg_csat
FROM shipments
GROUP BY clearance_band
ORDER BY MIN(clearance_hours);
