"""Generate 7 days of SYNTHETIC authentication + firewall logs for a small logistics company.

Normal staff activity is mixed with three planted attack scenarios so the
detection script has something real to find:
  1. SSH brute force from an external IP (then a successful login -> compromise)
  2. Password spraying against many usernames from a second IP
  3. Horizontal port scan against the DMZ
"""
import random
from datetime import datetime, timedelta
from pathlib import Path

random.seed(7)
D = Path(__file__).resolve().parents[1] / "data"
D.mkdir(exist_ok=True)
start = datetime(2026, 9, 14, 0, 0, 0)
users = ["t.mokoena", "a.naidoo", "j.vanwyk", "s.dlamini", "p.botha", "n.khumalo", "r.pillay", "k.smith", "admin", "svc_backup"]
office_ips = [f"10.20.1.{i}" for i in range(10, 60)]
vpn_ips = [f"196.25.{random.randint(1, 250)}.{random.randint(1, 250)}" for _ in range(12)]
auth, fw = [], []

def ts(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S")

# normal logins (business hours, occasional typo)
for day in range(7):
    for u in users[:8]:
        if day in (5, 6) and random.random() < 0.8:
            continue
        t = start + timedelta(days=day, hours=random.randint(7, 9), minutes=random.randint(0, 59))
        ip = random.choice(office_ips if random.random() < 0.8 else vpn_ips)
        if random.random() < 0.12:
            auth.append((ts(t), "srv-files01", u, ip, "FAILED", "invalid password"))
            t += timedelta(seconds=random.randint(10, 60))
        auth.append((ts(t), "srv-files01", u, ip, "SUCCESS", "password"))
    t = start + timedelta(days=day, hours=1, minutes=30)
    auth.append((ts(t), "srv-backup01", "svc_backup", "10.20.1.5", "SUCCESS", "publickey"))

# scenario 1: brute force then success (day 3, 02:10)
atk = "185.220.101.47"
t = start + timedelta(days=2, hours=2, minutes=10)
for i in range(46):
    auth.append((ts(t), "srv-web01", random.choice(["admin", "root", "admin"]), atk, "FAILED", "invalid password"))
    t += timedelta(seconds=random.randint(3, 9))
auth.append((ts(t), "srv-web01", "admin", atk, "SUCCESS", "password"))

# scenario 2: password spray (day 5, 22:40)
spray = "45.95.147.221"
t = start + timedelta(days=4, hours=22, minutes=40)
for u in users + ["finance", "hr", "ceo", "test", "guest", "support", "ops"]:
    auth.append((ts(t), "vpn-gw01", u, spray, "FAILED", "invalid password"))
    t += timedelta(seconds=random.randint(45, 90))

# firewall: normal + scan (day 6, 03:00)
for _ in range(1400):
    t = start + timedelta(seconds=random.randint(0, 7 * 86400))
    fw.append((ts(t), random.choice(office_ips), f"41.0.{random.randint(1, 250)}.{random.randint(1, 250)}", random.choice([443, 443, 443, 80, 53]), "ALLOW"))
scan = "92.118.39.12"
t = start + timedelta(days=5, hours=3)
for port in [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 1433, 3306, 3389, 5432, 5900, 8080, 8443]:
    for host in ["10.30.0.10", "10.30.0.11", "10.30.0.12"]:
        fw.append((ts(t), scan, host, port, "DENY" if port not in (80, 443) else "ALLOW"))
        t += timedelta(seconds=1)

auth.sort(); fw.sort()
with open(D / "auth.log", "w") as f:
    for r in auth:
        f.write(f"{r[0]} host={r[1]} user={r[2]} src={r[3]} result={r[4]} method={r[5]}\n")
with open(D / "firewall.log", "w") as f:
    for r in fw:
        f.write(f"{r[0]} src={r[1]} dst={r[2]} dport={r[3]} action={r[4]}\n")
print(len(auth), "auth events;", len(fw), "firewall events")
