"""Detection engine: parse auth + firewall logs, apply rules, write alerts and charts.

Rules (tuned for a ~10-user SME):
  R1  Brute force      >= 10 failed logins from one IP inside 5 minutes
  R2  Compromise       a SUCCESS from an IP that triggered R1 (critical)
  R3  Password spray   one IP failing against >= 8 distinct usernames in 30 minutes
  R4  Off-hours admin  privileged account login between 22:00 and 05:00
  R5  Port scan        one source touching >= 15 distinct ports in 10 minutes
"""
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, CORAL, AMBER, GREY  # noqa: E402

PAT = re.compile(r"(\S+) " + r" ".join(f"{k}=(\\S+)" for k in ["host", "user", "src", "result", "method"]))
FPAT = re.compile(r"(\S+) src=(\S+) dst=(\S+) dport=(\d+) action=(\S+)")
auth = pd.DataFrame([PAT.match(l).groups() for l in open(ROOT / "data" / "auth.log")],
                    columns=["ts", "host", "user", "src", "result", "method"])
fw = pd.DataFrame([FPAT.match(l).groups() for l in open(ROOT / "data" / "firewall.log")],
                  columns=["ts", "src", "dst", "dport", "action"])
auth["ts"] = pd.to_datetime(auth["ts"]); fw["ts"] = pd.to_datetime(fw["ts"]); fw["dport"] = fw["dport"].astype(int)
alerts = []

def alert(rule, sev, t, src, detail):
    alerts.append({"time": t, "rule": rule, "severity": sev, "source_ip": src, "detail": detail})

fails = auth[auth.result == "FAILED"].sort_values("ts")
bf_ips = set()
for ip, g in fails.groupby("src"):
    times = list(g.ts)
    for i in range(len(times)):
        j = i
        while j < len(times) and times[j] - times[i] <= timedelta(minutes=5):
            j += 1
        if j - i >= 10:
            bf_ips.add(ip)
            alert("R1 Brute force", "High", times[i], ip, f"{j - i} failures in 5 min on {g.host.iloc[0]} (users: {', '.join(sorted(set(g.user)))})")
            break
for _, r in auth[(auth.result == "SUCCESS") & auth.src.isin(bf_ips)].iterrows():
    alert("R2 Likely compromise", "Critical", r.ts, r.src, f"SUCCESS as '{r.user}' on {r.host} after brute force")
for ip, g in fails.groupby("src"):
    g = g.sort_values("ts")
    for i in range(len(g)):
        w = g[(g.ts >= g.ts.iloc[i]) & (g.ts <= g.ts.iloc[i] + timedelta(minutes=30))]
        if w.user.nunique() >= 8 and ip not in bf_ips:
            alert("R3 Password spray", "High", g.ts.iloc[i], ip, f"{w.user.nunique()} usernames tried on {g.host.iloc[0]}")
            break
priv = auth[(auth.result == "SUCCESS") & auth.user.isin(["admin", "root"]) & ((auth.ts.dt.hour >= 22) | (auth.ts.dt.hour < 5))]
for _, r in priv.iterrows():
    alert("R4 Off-hours admin login", "Medium", r.ts, r.src, f"'{r.user}' logged in at {r.ts:%H:%M} on {r.host}")
for ip, g in fw.groupby("src"):
    g = g.sort_values("ts")
    w = g[g.ts <= g.ts.iloc[0] + timedelta(minutes=10)]
    if w.dport.nunique() >= 15:
        alert("R5 Port scan", "Medium", g.ts.iloc[0], ip, f"{w.dport.nunique()} ports x {w.dst.nunique()} hosts in 10 min ({(w.action == 'DENY').sum()} denied)")

al = pd.DataFrame(alerts).sort_values("time")
out = ROOT / "outputs"; out.mkdir(exist_ok=True)
al.to_csv(out / "alerts.csv", index=False)
print(al.to_string(index=False))

# SQL layer (mirrors the Google Cybersecurity SQL labs)
con = sqlite3.connect(":memory:"); auth.assign(ts=auth.ts.astype(str)).to_sql("log_in_attempts", con, index=False)
q = (ROOT / "sql" / "investigation_queries.sql").read_text()
for block in q.split("-- name: ")[1:]:
    name, sql = block.split("\n", 1)
    pd.read_sql_query(sql, con).to_csv(out / f"sql_{name.strip()}.csv", index=False)

# charts
fails = auth[auth.result == "FAILED"].copy(); fails["hour"] = fails.ts.dt.floor("h")
hourly = fails.groupby("hour").size()
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.bar(hourly.index, hourly.values, width=0.035, color=[CORAL if v >= 10 else TEAL for v in hourly.values])
ax.set_title("Failed logins per hour — spikes = attacks (red)"); ax.set_ylabel("Failed logins")
save(fig, out / "chart_failed_logins_timeline.png")
top = fails.src.value_counts().head(6)
fig, ax = plt.subplots(figsize=(5.5, 3.2))
b = ax.barh(top.index[::-1], top.values[::-1], color=[CORAL if ip in bf_ips or v > 10 else TEAL for ip, v in zip(top.index[::-1], top.values[::-1])])
ax.bar_label(b, padding=3, fontsize=8.5); ax.set_title("Top sources of failed logins")
save(fig, out / "chart_top_failed_sources.png")
sev = al.severity.value_counts().reindex(["Critical", "High", "Medium"]).fillna(0)
fig, ax = plt.subplots(figsize=(4.2, 3.2))
ax.pie(sev.values, labels=[f"{k} ({int(v)})" for k, v in sev.items()], colors=[CORAL, AMBER, TEAL2], startangle=90,
       wedgeprops=dict(width=0.4, edgecolor="white"))
ax.set_title("Alerts by severity")
save(fig, out / "chart_alert_severity.png")

rr = pd.read_csv(ROOT / "data" / "risk_register.csv"); rr["score"] = rr.likelihood * rr.impact
rr.to_csv(out / "risk_register_scored.csv", index=False)
fig, ax = plt.subplots(figsize=(6, 4.2))
for x in range(1, 6):
    for y in range(1, 6):
        s = x * y
        ax.add_patch(plt.Rectangle((x - 0.5, y - 0.5), 1, 1, color="#E8F6F3" if s < 6 else ("#FDF1DD" if s < 12 else "#FBE0D8")))
for _, r in rr.iterrows():
    ax.scatter(r.likelihood + (hash(r.risk_id) % 5 - 2) * 0.08, r.impact + (hash(r.risk_id[::-1]) % 5 - 2) * 0.08, s=140,
               color=PURPLE, zorder=3)
    ax.text(r.likelihood + 0.18, r.impact + 0.12, r.risk_id, fontsize=7.5, zorder=4)
ax.set_xlim(0.5, 5.5); ax.set_ylim(0.5, 5.5); ax.set_xlabel("Likelihood"); ax.set_ylabel("Impact"); ax.grid(False)
ax.set_title("Risk heat map (NIST CSF aligned register)")
save(fig, out / "chart_risk_heatmap.png")
print("charts + sql outputs written")
