-- Investigation queries against table log_in_attempts (SQLite / MySQL compatible)

-- name: failed_after_hours
-- Failed logins outside business hours (before 07:00 or after 18:00)
SELECT ts, host, user, src
FROM log_in_attempts
WHERE result = 'FAILED'
  AND (CAST(strftime('%H', ts) AS INTEGER) >= 18 OR CAST(strftime('%H', ts) AS INTEGER) < 7)
ORDER BY ts;

-- name: external_sources
-- Any login attempt that did not originate from the office subnet 10.20.1.0/24
SELECT src, COUNT(*) AS attempts,
       SUM(CASE WHEN result = 'FAILED' THEN 1 ELSE 0 END) AS failures,
       COUNT(DISTINCT user) AS distinct_users
FROM log_in_attempts
WHERE src NOT LIKE '10.20.1.%'
GROUP BY src
ORDER BY failures DESC;

-- name: privileged_accounts
-- Every attempt against privileged / shared accounts
SELECT ts, host, user, src, result
FROM log_in_attempts
WHERE user IN ('admin', 'root', 'svc_backup')
  AND src <> '10.20.1.5'
ORDER BY ts;

-- name: users_to_reset
-- Accounts targeted by the external attackers -> force password reset + MFA check
SELECT DISTINCT user
FROM log_in_attempts
WHERE src IN ('185.220.101.47', '45.95.147.221')
ORDER BY user;
