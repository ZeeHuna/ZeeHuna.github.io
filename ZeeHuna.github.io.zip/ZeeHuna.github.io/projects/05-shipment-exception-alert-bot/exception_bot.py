"""Shipment Exception Alert Bot
================================
Reads the daily open-shipment extract, applies configurable exception rules,
and produces (1) a formatted Excel action list with a chart, (2) an HTML
email briefing for team leads, and (3) a run log. Replaces a manual
status-check routine that took an analyst ~45 minutes each morning.

Usage:
    python exception_bot.py --input data/open_shipments.csv --asof "2026-09-29 07:00"
"""
from __future__ import annotations

import argparse
import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parent
SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2}
SEV_FILL = {"Critical": "F8D3CA", "High": "FCE8C8", "Medium": "E3F4F7"}


@dataclass(frozen=True)
class Rule:
    code: str
    name: str
    severity: str
    owner: str
    action: str


def load_config(path: Path) -> dict:
    return json.loads(path.read_text())


def flag_exceptions(df: pd.DataFrame, asof: datetime, cfg: dict) -> pd.DataFrame:
    """Return one row per (shipment, rule) hit. Pure function -> easy to unit test."""
    t = cfg["thresholds"]
    df = df.copy()
    df["last_scan"] = pd.to_datetime(df["last_scan"])
    df["due_date"] = pd.to_datetime(df["due_date"])
    df["hours_since_scan"] = (asof - df["last_scan"]).dt.total_seconds() / 3600
    df["hours_to_due"] = (df["due_date"] - asof).dt.total_seconds() / 3600
    rules = {r["code"]: Rule(**r) for r in cfg["rules"]}
    hits = []

    def add(mask, code):
        sub = df[mask].copy()
        r = rules[code]
        sub["rule"], sub["exception"], sub["severity"], sub["owner"], sub["action"] = r.code, r.name, r.severity, r.owner, r.action
        hits.append(sub)

    add((df["hours_since_scan"] > t["no_scan_hours"]) & (df["status"] != "Delivered"), "E1")
    add((df["status"] == "Customs Hold") & (df["hours_since_scan"] > t["customs_hold_hours"]), "E2")
    add((df["hours_to_due"] < t["sla_risk_hours"]) & (df["hours_to_due"] >= 0) & df["status"].isin(["In Transit", "At Origin Hub", "Customs Hold"]), "E3")
    add(df["hours_to_due"] < 0, "E4")
    add(df["status"].isin(["Address Query", "Consignee Unavailable"]), "E5")
    add((df["priority"] == "Healthcare") & (df["status"] != "Delivered") & (df["hours_to_due"] < t["healthcare_risk_hours"]), "E6")

    out = pd.concat(hits, ignore_index=True) if hits else df.head(0)
    out["sev_rank"] = out["severity"].map(SEV_ORDER)
    return out.sort_values(["sev_rank", "hours_to_due"]).drop(columns="sev_rank").reset_index(drop=True)


def write_excel(ex: pd.DataFrame, summary: pd.DataFrame, path: Path, asof: datetime) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = f"Shipment exceptions — {asof:%d %b %Y %H:%M}"
    ws["A1"].font = Font(size=14, bold=True, color="1D1160")
    ws.append([])
    ws.append(list(summary.columns))
    for r in summary.itertuples(index=False):
        ws.append(list(r))
    for c in ws[3]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="00788C")
    ch = BarChart(); ch.type = "bar"; ch.title = "Exceptions by type"; ch.legend = None; ch.height, ch.width = 7, 14
    ch.add_data(Reference(ws, min_col=3, min_row=3, max_row=3 + len(summary)), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=4, max_row=3 + len(summary)))
    ws.add_chart(ch, "F3")
    for col, w in zip("ABCD", (34, 12, 12, 26)):
        ws.column_dimensions[col].width = w

    ws2 = wb.create_sheet("Action list")
    cols = ["severity", "exception", "shipment_id", "customer", "priority", "status", "origin", "destination",
            "hours_since_scan", "hours_to_due", "owner", "action"]
    ws2.append([c.replace("_", " ").title() for c in cols])
    for c in ws2[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1D1160")
        c.alignment = Alignment(wrap_text=True)
    for r in ex[cols].itertuples(index=False):
        ws2.append([round(v, 1) if isinstance(v, float) else v for v in r])
        fill = PatternFill("solid", fgColor=SEV_FILL[r.severity])
        for c in ws2[ws2.max_row]:
            c.fill = fill
    for i, w in enumerate((10, 26, 16, 22, 12, 20, 9, 12, 10, 10, 18, 46), 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    ws2.freeze_panes = "A2"; ws2.auto_filter.ref = ws2.dimensions
    wb.save(path)


def write_email(ex: pd.DataFrame, summary: pd.DataFrame, path: Path, asof: datetime, n_open: int) -> None:
    crit = ex[ex.severity == "Critical"].head(8)
    rows = "".join(f"<tr><td>{r.shipment_id}</td><td>{r.customer}</td><td>{r.exception}</td><td>{r.hours_to_due:.0f}h</td><td>{r.action}</td></tr>"
                   for r in crit.itertuples())
    srows = "".join(f"<tr><td>{r.exception}</td><td>{r.severity}</td><td style='text-align:right'>{r.shipments}</td></tr>" for r in summary.itertuples())
    html = f"""<html><body style="font-family:Arial;color:#1E2632">
<h2 style="color:#1D1160">Morning exception briefing — {asof:%a %d %b %Y}</h2>
<p><b>{ex.shipment_id.nunique()}</b> of <b>{n_open}</b> open shipments need action today
(<b style="color:#E4572E">{(ex.severity == 'Critical').sum()} critical</b>). Full list attached (Excel).</p>
<table cellpadding="6" style="border-collapse:collapse" border="1"><tr style="background:#00788C;color:white"><th>Exception</th><th>Severity</th><th>Shipments</th></tr>{srows}</table>
<h3>Top critical items</h3>
<table cellpadding="6" style="border-collapse:collapse" border="1"><tr style="background:#1D1160;color:white"><th>AWB</th><th>Customer</th><th>Exception</th><th>Due in</th><th>Action</th></tr>{rows}</table>
<p style="color:#6B7785;font-size:12px">Generated automatically by exception_bot.py</p></body></html>"""
    path.write_text(html)


def main(argv=None) -> pd.DataFrame:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=str(ROOT / "data" / "open_shipments.csv"))
    ap.add_argument("--config", default=str(ROOT / "config" / "rules.json"))
    ap.add_argument("--asof", default="2026-09-29 07:00")
    ap.add_argument("--outdir", default=str(ROOT / "outputs"))
    a = ap.parse_args(argv)
    out = Path(a.outdir); out.mkdir(exist_ok=True)
    logging.basicConfig(filename=out / "run.log", level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", filemode="w")
    asof = datetime.fromisoformat(a.asof)
    df = pd.read_csv(a.input)
    logging.info("Loaded %s open shipments from %s", len(df), a.input)
    ex = flag_exceptions(df, asof, load_config(Path(a.config)))
    summary = (ex.groupby(["exception", "severity"]).shipment_id.nunique().reset_index(name="shipments")
               .assign(o=lambda d: d.severity.map(SEV_ORDER)).sort_values(["o", "shipments"], ascending=[True, False]).drop(columns="o"))
    summary.insert(3, "owner", summary.exception.map(ex.drop_duplicates("exception").set_index("exception").owner))
    write_excel(ex, summary, out / f"exceptions_{asof:%Y%m%d}.xlsx", asof)
    write_email(ex, summary, out / f"briefing_{asof:%Y%m%d}.html", asof, len(df))
    logging.info("Flagged %s exception rows on %s shipments", len(ex), ex.shipment_id.nunique())
    print(summary.to_string(index=False))
    print(f"\n{ex.shipment_id.nunique()} of {len(df)} shipments need action · outputs in {out}")
    return ex


if __name__ == "__main__":
    main()
