from datetime import datetime
from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from exception_bot import flag_exceptions, load_config  # noqa: E402

CFG = load_config(ROOT / "config" / "rules.json")
ASOF = datetime(2026, 9, 29, 7, 0)


def frame(**kw):
    base = dict(shipment_id="AWB1", customer="X", priority="Standard", origin="JNB", destination="CPT",
                status="In Transit", last_scan="2026-09-29 05:00", due_date="2026-09-30 18:00")
    base.update(kw)
    return pd.DataFrame([base])


def rules_hit(**kw):
    return set(flag_exceptions(frame(**kw), ASOF, CFG)["rule"])


def test_healthy_shipment_has_no_exception():
    assert rules_hit() == set()


def test_no_scan_over_24h():
    assert "E1" in rules_hit(last_scan="2026-09-28 05:00")


def test_customs_hold_over_48h_is_critical():
    out = flag_exceptions(frame(status="Customs Hold", last_scan="2026-09-26 06:00"), ASOF, CFG)
    assert "E2" in set(out.rule) and out.loc[out.rule == "E2", "severity"].item() == "Critical"


def test_sla_risk_window():
    assert "E3" in rules_hit(due_date="2026-09-29 15:00")
    assert "E3" not in rules_hit(due_date="2026-09-30 15:00")


def test_breached_sla():
    assert "E4" in rules_hit(due_date="2026-09-28 17:00")


def test_address_issue():
    assert "E5" in rules_hit(status="Address Query")


def test_healthcare_priority_escalates():
    assert "E6" in rules_hit(priority="Healthcare", due_date="2026-09-29 20:00")


def test_critical_items_sorted_first():
    df = pd.concat([frame(shipment_id="A", status="Address Query"),
                    frame(shipment_id="B", due_date="2026-09-28 10:00")])
    out = flag_exceptions(df, ASOF, CFG)
    assert out.iloc[0]["severity"] == "Critical"
