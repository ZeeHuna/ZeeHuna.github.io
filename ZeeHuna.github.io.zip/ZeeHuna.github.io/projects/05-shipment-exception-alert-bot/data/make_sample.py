"""Create a SYNTHETIC open-shipment extract (600 rows) for the bot."""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(29)
N = 600
asof = pd.Timestamp("2026-09-29 07:00")
status = rng.choice(["In Transit", "At Origin Hub", "Customs Hold", "Out for Delivery", "Address Query", "Consignee Unavailable"],
                    N, p=[0.5, 0.14, 0.14, 0.14, 0.04, 0.04])
hours_since = np.round(rng.gamma(2.0, 4.6, N) + np.where(status == "Customs Hold", rng.uniform(10, 60, N), 0), 1)
hours_due = np.round(rng.normal(44, 22, N), 1)
df = pd.DataFrame({
    "shipment_id": [f"AWB{8800000000 + i}" for i in range(N)],
    "customer": rng.choice(["Online Fashion Co", "PharmaLink SA", "TechDirect", "HomeGoods Online", "AutoParts Hub", "BookNook", "Beauty Box"], N),
    "priority": rng.choice(["Standard", "Express", "Healthcare"], N, p=[0.55, 0.37, 0.08]),
    "origin": rng.choice(["JNB", "CPT", "DUR", "LHR", "FRA", "DXB"], N),
    "destination": rng.choice(["JNB", "CPT", "DUR", "PLZ", "BFN"], N),
    "status": status,
    "last_scan": (asof - pd.to_timedelta(hours_since, unit="h")).strftime("%Y-%m-%d %H:%M"),
    "due_date": (asof + pd.to_timedelta(hours_due, unit="h")).strftime("%Y-%m-%d %H:%M"),
})
df.to_csv(Path(__file__).parent / "open_shipments.csv", index=False)
print("rows", len(df))
