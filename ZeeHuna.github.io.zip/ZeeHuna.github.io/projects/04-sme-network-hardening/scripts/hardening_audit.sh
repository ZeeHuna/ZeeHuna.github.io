#!/usr/bin/env bash
# =====================================================================
#  Linux Server Hardening Audit  (read-only, safe to run as root or user)
#  Checks a host against a CIS-style baseline and prints PASS / FAIL /
#  WARN with a score. Writes a CSV report next to the script.
#  Usage:  sudo ./hardening_audit.sh [output.csv]
# =====================================================================
set -u
OUT="${1:-audit_report.csv}"
PASS=0; FAIL=0; WARN=0
echo "check_id,category,check,result,evidence" > "$OUT"

record() {  # id category description result evidence
  printf '%-6s %-10s %-52s %s\n' "$1" "$4" "$3" "${5:0:60}"
  echo "$1,$2,\"$3\",$4,\"${5//\"/\'}\"" >> "$OUT"
  case "$4" in PASS) PASS=$((PASS+1));; FAIL) FAIL=$((FAIL+1));; *) WARN=$((WARN+1));; esac
}

sshd_opt() { grep -Ei "^\s*$1\s+" /etc/ssh/sshd_config 2>/dev/null | tail -1 | awk '{print tolower($2)}'; }

echo "== Host: $(hostname)  Kernel: $(uname -r)  Date: $(date -u +%FT%TZ) =="

# ---- 1. SSH ----
if [ -f /etc/ssh/sshd_config ]; then
  v=$(sshd_opt PermitRootLogin); [ "$v" = "no" ] && record S1 SSH "Root login over SSH disabled" PASS "PermitRootLogin=$v" || record S1 SSH "Root login over SSH disabled" FAIL "PermitRootLogin=${v:-default}"
  v=$(sshd_opt PasswordAuthentication); [ "$v" = "no" ] && record S2 SSH "Key-only SSH (password auth off)" PASS "PasswordAuthentication=$v" || record S2 SSH "Key-only SSH (password auth off)" FAIL "PasswordAuthentication=${v:-default yes}"
  v=$(sshd_opt MaxAuthTries); [ -n "$v" ] && [ "$v" -le 4 ] && record S3 SSH "MaxAuthTries <= 4" PASS "MaxAuthTries=$v" || record S3 SSH "MaxAuthTries <= 4" FAIL "MaxAuthTries=${v:-default 6}"
else
  record S0 SSH "OpenSSH server installed" WARN "no sshd_config (service not installed)"
fi

# ---- 2. Firewall ----
if command -v ufw >/dev/null 2>&1; then
  ufw status 2>/dev/null | grep -q "Status: active" && record F1 Firewall "Host firewall (ufw) active" PASS "ufw active" || record F1 Firewall "Host firewall (ufw) active" FAIL "ufw inactive"
elif command -v nft >/dev/null 2>&1 && nft list ruleset 2>/dev/null | grep -q "chain"; then
  record F1 Firewall "Host firewall active" PASS "nftables ruleset present"
elif command -v iptables >/dev/null 2>&1 && [ "$(iptables -S 2>/dev/null | wc -l)" -gt 3 ]; then
  record F1 Firewall "Host firewall active" PASS "iptables rules present"
else
  record F1 Firewall "Host firewall active" FAIL "no ufw/nftables/iptables rules found"
fi

# ---- 3. Listening services ----
if command -v ss >/dev/null 2>&1; then
  LISTEN=$(ss -tulnH 2>/dev/null | awk '{print $5}' | sed 's/.*://' | sort -un | tr '\n' ' ')
  RISKY=$(for p in $LISTEN; do case $p in 21|23|69|111|139|445|3389|5900) echo -n "$p ";; esac; done)
  [ -z "$RISKY" ] && record N1 Network "No risky legacy ports listening (21,23,445,3389...)" PASS "listening: ${LISTEN:-none}" || record N1 Network "No risky legacy ports listening" FAIL "risky: $RISKY"
else
  record N1 Network "Listening ports reviewed" WARN "ss not available"
fi
[ "$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null)" = "0" ] && record N2 Network "IP forwarding disabled (not a router)" PASS "ip_forward=0" || record N2 Network "IP forwarding disabled (not a router)" WARN "ip_forward=$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null)"
[ "$(cat /proc/sys/net/ipv4/conf/all/accept_redirects 2>/dev/null)" = "0" ] && record N3 Network "ICMP redirects ignored" PASS "accept_redirects=0" || record N3 Network "ICMP redirects ignored" FAIL "accept_redirects=$(cat /proc/sys/net/ipv4/conf/all/accept_redirects 2>/dev/null)"
[ "$(cat /proc/sys/net/ipv4/tcp_syncookies 2>/dev/null)" = "1" ] && record N4 Network "SYN cookies enabled (SYN-flood protection)" PASS "tcp_syncookies=1" || record N4 Network "SYN cookies enabled" FAIL "tcp_syncookies=$(cat /proc/sys/net/ipv4/tcp_syncookies 2>/dev/null)"

# ---- 4. Accounts ----
UID0=$(awk -F: '$3==0{print $1}' /etc/passwd | tr '\n' ' ')
[ "$UID0" = "root " ] && record A1 Accounts "Only root has UID 0" PASS "uid0: $UID0" || record A1 Accounts "Only root has UID 0" FAIL "uid0: $UID0"
if [ -r /etc/shadow ]; then
  EMPTY=$(awk -F: '($2==""){print $1}' /etc/shadow | tr '\n' ' ')
  [ -z "$EMPTY" ] && record A2 Accounts "No accounts with empty passwords" PASS "none" || record A2 Accounts "No accounts with empty passwords" FAIL "$EMPTY"
else
  record A2 Accounts "No accounts with empty passwords" WARN "run as root to read /etc/shadow"
fi
v=$(grep -E "^PASS_MAX_DAYS" /etc/login.defs 2>/dev/null | awk '{print $2}')
[ -n "$v" ] && [ "$v" -le 90 ] && record A3 Accounts "Password max age <= 90 days" PASS "PASS_MAX_DAYS=$v" || record A3 Accounts "Password max age <= 90 days" FAIL "PASS_MAX_DAYS=${v:-unset}"

# ---- 5. File permissions ----
p=$(stat -c %a /etc/passwd 2>/dev/null); [ "$p" = "644" ] && record P1 Files "/etc/passwd permissions 644" PASS "$p" || record P1 Files "/etc/passwd permissions 644" FAIL "$p"
p=$(stat -c %a /etc/shadow 2>/dev/null); case "$p" in 0|600|640) record P2 Files "/etc/shadow not world-readable" PASS "$p";; *) record P2 Files "/etc/shadow not world-readable" FAIL "${p:-missing}";; esac
WW=$(find /etc -xdev -type f -perm -0002 2>/dev/null | head -5 | tr '\n' ' ')
[ -z "$WW" ] && record P3 Files "No world-writable files in /etc" PASS "none" || record P3 Files "No world-writable files in /etc" FAIL "$WW"

# ---- 6. Patching & logging ----
if [ -f /etc/apt/apt.conf.d/20auto-upgrades ] && grep -q '"1"' /etc/apt/apt.conf.d/20auto-upgrades; then
  record U1 Patching "Automatic security updates enabled" PASS "unattended-upgrades on"
else
  record U1 Patching "Automatic security updates enabled" FAIL "unattended-upgrades not configured"
fi
if command -v apt >/dev/null 2>&1; then
  n=$(apt list --upgradable 2>/dev/null | grep -c upgradable); [ "$n" -eq 0 ] && record U2 Patching "No pending package updates" PASS "0 pending" || record U2 Patching "No pending package updates" WARN "$n pending"
fi
{ pgrep -x rsyslogd || pgrep -x systemd-journald || pgrep -x syslog-ng; } >/dev/null 2>&1 && record L1 Logging "System logging daemon running" PASS "logger found" || record L1 Logging "System logging daemon running" FAIL "no rsyslog/journald"
command -v auditd >/dev/null 2>&1 && record L2 Logging "auditd installed" PASS "auditd present" || record L2 Logging "auditd installed" FAIL "auditd missing"
command -v fail2ban-client >/dev/null 2>&1 && record L3 Logging "fail2ban installed (brute-force defence)" PASS "present" || record L3 Logging "fail2ban installed (brute-force defence)" FAIL "missing"

TOTAL=$((PASS+FAIL+WARN)); SCORE=$(( 100 * PASS / (PASS+FAIL) ))
echo "-----------------------------------------------------------------------"
echo "PASS=$PASS  FAIL=$FAIL  WARN=$WARN  of $TOTAL checks   Compliance score: ${SCORE}%"
echo "Report written to $OUT"
