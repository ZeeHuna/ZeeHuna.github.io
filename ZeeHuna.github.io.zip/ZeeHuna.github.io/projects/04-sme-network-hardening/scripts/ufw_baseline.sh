#!/usr/bin/env bash
# Default-deny host firewall baseline for the branch file / web servers.
# Review before running: it changes firewall state.
set -euo pipefail
MGMT_VLAN="10.20.99.0/24"     # IT management VLAN (only place SSH is allowed from)
STAFF_VLAN="10.20.10.0/24"

ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow from "$MGMT_VLAN" to any port 22 proto tcp comment 'SSH from management VLAN only'
ufw allow from "$STAFF_VLAN" to any port 445 proto tcp comment 'SMB file shares for staff VLAN'
ufw allow 443/tcp comment 'HTTPS'
ufw limit 22/tcp comment 'rate-limit SSH (6 conn / 30s)'
ufw logging medium
ufw --force enable
ufw status verbose
