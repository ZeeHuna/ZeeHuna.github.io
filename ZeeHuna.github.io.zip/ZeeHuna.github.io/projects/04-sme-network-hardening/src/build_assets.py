"""Build the network design artefacts: topology diagram, asset inventory analysis,
before/after CIS-style compliance scorecard and patch-compliance chart.
All data is SYNTHETIC for a 45-person logistics branch office."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, CORAL, AMBER, GREY, INK  # noqa: E402

O = ROOT / "outputs"; D = ROOT / "data"; O.mkdir(exist_ok=True); D.mkdir(exist_ok=True)
rng = np.random.default_rng(4)

# ---------- asset inventory ----------
types = [("Laptop", 30, "Windows 11"), ("Desktop", 8, "Windows 10"), ("Server", 3, "Ubuntu 22.04"), ("Switch", 3, "Cisco IOS"),
         ("Firewall", 1, "pfSense"), ("Wireless AP", 4, "UniFi"), ("Printer", 3, "Vendor FW"), ("CCTV NVR", 1, "Vendor FW"),
         ("Handheld scanner", 12, "Android 11")]
rows = []
for t, n, os_ in types:
    for i in range(n):
        vlan = {"Server": 20, "Switch": 99, "Firewall": 99, "Wireless AP": 99, "Printer": 30, "CCTV NVR": 40, "Handheld scanner": 30}.get(t, 10)
        patched_before = rng.random() < {"Laptop": 0.72, "Desktop": 0.5, "Server": 0.34, "Printer": 0.3, "CCTV NVR": 0.0, "Handheld scanner": 0.6}.get(t, 0.7)
        rows.append({"asset_id": f"{t[:3].upper()}-{i + 1:02d}", "type": t, "os_firmware": os_, "vlan": vlan,
                     "owner": "IT" if t in ("Server", "Switch", "Firewall", "Wireless AP") else "Operations",
                     "criticality": "High" if t in ("Server", "Firewall", "Switch") else ("Medium" if t in ("Laptop", "Handheld scanner", "CCTV NVR") else "Low"),
                     "patched_before": "Yes" if patched_before else "No",
                     "patched_after": "Yes" if (patched_before or rng.random() < 0.93) else "No",
                     "disk_encrypted": "Yes" if t == "Laptop" and rng.random() < 0.95 else ("N/A" if t not in ("Laptop", "Desktop") else "No")})
inv = pd.DataFrame(rows); inv.to_csv(D / "asset_inventory.csv", index=False)
pc = inv.groupby("type").agg(assets=("asset_id", "count"), before=("patched_before", lambda s: (s == "Yes").mean()),
                              after=("patched_after", lambda s: (s == "Yes").mean())).sort_values("assets")
pc.to_csv(O / "patch_compliance_by_type.csv")

# ---------- CIS-style scorecard ----------
controls = pd.DataFrame([
    ("Inventory of hardware assets", "CIS 1", 40, 100), ("Inventory of software", "CIS 2", 25, 90),
    ("Data protection / encryption", "CIS 3", 35, 88), ("Secure configuration baselines", "CIS 4", 30, 85),
    ("Account management", "CIS 5", 45, 95), ("Access control & MFA", "CIS 6", 20, 90),
    ("Vulnerability management / patching", "CIS 7", 52, 94), ("Audit log management", "CIS 8", 25, 80),
    ("Email & browser protections", "CIS 9", 50, 85), ("Malware defences", "CIS 10", 70, 95),
    ("Data recovery (3-2-1 backups)", "CIS 11", 40, 100), ("Network infrastructure mgmt", "CIS 12", 35, 90),
    ("Security awareness training", "CIS 14", 15, 75)], columns=["control", "ref", "before_pct", "after_pct"])
controls.to_csv(O / "cis_scorecard.csv", index=False)

fig, ax = plt.subplots(figsize=(7.5, 4.6))
y = np.arange(len(controls))
ax.barh(y + 0.2, controls.before_pct, 0.4, color="#D5DBE1", label="Before")
ax.barh(y - 0.2, controls.after_pct, 0.4, color=TEAL, label="After hardening")
ax.set_yticks(y); ax.set_yticklabels([f"{r} {c}" for r, c in zip(controls.ref, controls.control)], fontsize=8)
ax.invert_yaxis(); ax.set_xlim(0, 105); ax.legend(loc="lower right", fontsize=8.5)
ax.set_title(f"CIS Controls maturity: {controls.before_pct.mean():.0f}% -> {controls.after_pct.mean():.0f}%")
save(fig, O / "chart_cis_scorecard.png")

fig, ax = plt.subplots(figsize=(6.4, 3.6))
yy = np.arange(len(pc))
ax.barh(yy + 0.2, pc.before * 100, 0.4, color="#D5DBE1", label="Before")
ax.barh(yy - 0.2, pc.after * 100, 0.4, color=PURPLE, label="After")
ax.set_yticks(yy); ax.set_yticklabels(pc.index, fontsize=8.5); ax.legend(fontsize=8.5, loc="lower right")
ax.set_title(f"Patch compliance: {(inv.patched_before == 'Yes').mean():.0%} -> {(inv.patched_after == 'Yes').mean():.0%} of {len(inv)} assets")
save(fig, O / "chart_patch_compliance.png")

# ---------- topology diagram ----------
fig, ax = plt.subplots(figsize=(9, 5.6)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 6.4); ax.grid(False)
def node(x, y, label, sub, color, w=1.7):
    ax.add_patch(plt.Rectangle((x - w / 2, y - 0.32), w, 0.64, facecolor="white", edgecolor=color, lw=2, zorder=3))
    ax.text(x, y + 0.06, label, ha="center", fontsize=8.6, fontweight="bold", color=INK, zorder=4)
    ax.text(x, y - 0.18, sub, ha="center", fontsize=7, color=GREY, zorder=4)
def link(a, b, c=GREY, ls="-"):
    ax.plot([a[0], b[0]], [a[1], b[1]], color=c, lw=1.6, ls=ls, zorder=1)
net = (5, 5.9); fw = (5, 4.9); core = (5, 3.8)
node(*net, "Internet / ISP fibre", "Dual WAN + LTE failover", GREY)
node(*fw, "pfSense firewall", "IDS (Suricata) · VPN · MFA", CORAL)
node(*core, "Core L3 switch", "Inter-VLAN ACLs", PURPLE)
link(net, fw); link(fw, core)
dmz = (8.3, 4.9); node(*dmz, "DMZ VLAN 50", "Web server · reverse proxy", AMBER); link(fw, dmz, AMBER)
vl = [(1.0, "VLAN 10 Staff", "38 PCs / laptops"), (3.0, "VLAN 20 Servers", "File · Backup · App"),
      (5.0, "VLAN 30 Operations", "Scanners · printers"), (7.0, "VLAN 40 CCTV/IoT", "Isolated, no internet"),
      (9.0, "VLAN 99 Mgmt", "Switch/AP admin only")]
for x, a, b in vl:
    node(x, 2.2, a, b, TEAL, 1.8); link(core, (x, 2.2), TEAL)
node(3.0, 0.8, "Offsite / cloud backup", "Immutable, daily + weekly", TEAL2, 2.1); link((3.0, 2.2), (3.0, 0.8), TEAL2, "--")
node(7.8, 0.8, "Guest Wi-Fi", "Internet-only, client isolation", GREY, 2.1); link(fw, (7.8, 0.8), GREY, ":")
ax.set_title("Branch network after hardening — segmented VLANs, default-deny between zones")
save(fig, O / "network_topology.png")
print(controls[["before_pct", "after_pct"]].mean().round(1).to_dict(), (inv.patched_before == "Yes").mean(), (inv.patched_after == "Yes").mean())
