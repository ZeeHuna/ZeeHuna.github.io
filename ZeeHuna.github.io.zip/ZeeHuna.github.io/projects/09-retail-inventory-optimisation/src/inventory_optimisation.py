"""Retail inventory optimisation: ABC-XYZ segmentation, safety stock, reorder points and
stock-health flags for 1,200 SKUs across 52 weeks (SYNTHETIC data modelled on an
omnichannel fashion/home retailer). Mirrors the SKU-governance work I did managing
50,000+ SKUs in e-commerce retail.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, CORAL, AMBER, GREY  # noqa: E402

rng = np.random.default_rng(50)
D = ROOT / "data"; O = ROOT / "outputs"; D.mkdir(exist_ok=True); O.mkdir(exist_ok=True)
N, W = 1200, 52
cats = ["Womenswear", "Menswear", "Kids", "Footwear", "Home", "Beauty"]
sku = pd.DataFrame({"sku": [f"SKU{10000 + i}" for i in range(N)], "category": rng.choice(cats, N),
                    "unit_cost": np.round(rng.lognormal(4.6, 0.6, N), 2)})
sku["unit_price"] = np.round(sku.unit_cost * rng.uniform(1.8, 2.6, N), 2)
base = rng.lognormal(2.0, 1.45, N)
cv_level = rng.choice([0.15, 0.45, 1.1], N, p=[0.35, 0.4, 0.25])
weeks = np.arange(W)
season = 1 + 0.25 * np.sin(2 * np.pi * (weeks - 40) / 52) + np.where(weeks >= 46, 0.6, 0)
demand = np.maximum(0, np.round(base[:, None] * season[None, :] * rng.normal(1, cv_level[:, None], (N, W)))).astype(int)
pd.DataFrame(demand, columns=[f"W{w + 1:02d}" for w in weeks]).assign(sku=sku.sku).to_csv(D / "weekly_demand.csv", index=False)

sku["annual_units"] = demand.sum(1)
sku["annual_revenue"] = sku.annual_units * sku.unit_price
sku["avg_weekly"] = demand.mean(1)
sku["cv"] = np.where(sku.avg_weekly > 0, demand.std(1) / np.maximum(sku.avg_weekly, 1e-9), 9)
sku = sku.sort_values("annual_revenue", ascending=False).reset_index(drop=True)
sku["cum_rev_pct"] = sku.annual_revenue.cumsum() / sku.annual_revenue.sum()
sku["ABC"] = np.where(sku.cum_rev_pct <= 0.8, "A", np.where(sku.cum_rev_pct <= 0.95, "B", "C"))
sku["XYZ"] = np.where(sku.cv <= 0.5, "X", np.where(sku.cv <= 1.0, "Y", "Z"))
sku["segment"] = sku.ABC + sku.XYZ

lead_weeks = rng.choice([2, 3, 4, 6], N, p=[0.3, 0.35, 0.25, 0.1])
z = sku.ABC.map({"A": 1.65, "B": 1.28, "C": 0.84})           # 95% / 90% / 80% service targets
sku["lead_time_weeks"] = lead_weeks
sku["weekly_sd"] = sku.cv * sku.avg_weekly
sku["safety_stock"] = np.ceil(z * sku.weekly_sd * np.sqrt(sku.lead_time_weeks))
sku["reorder_point"] = np.ceil(sku.avg_weekly * sku.lead_time_weeks + sku.safety_stock)
sku["on_hand"] = np.round(sku.reorder_point * rng.lognormal(0.42, 0.5, N))
sku["weeks_cover"] = np.where(sku.avg_weekly > 0, sku.on_hand / sku.avg_weekly, 99)
sku["status"] = np.select([sku.on_hand < sku.safety_stock, sku.on_hand < sku.reorder_point, sku.weeks_cover > 16],
                          ["Stock-out risk", "Reorder now", "Overstock"], "Healthy")
sku["stock_value"] = sku.on_hand * sku.unit_cost
excess_units = np.maximum(sku.on_hand - sku.avg_weekly * 12, 0)
sku["excess_value"] = np.where(sku.status == "Overstock", excess_units * sku.unit_cost, 0)
sku.to_csv(O / "sku_policy.csv", index=False)

seg = sku.pivot_table(index="ABC", columns="XYZ", values="sku", aggfunc="count", fill_value=0)
segrev = sku.pivot_table(index="ABC", columns="XYZ", values="annual_revenue", aggfunc="sum", fill_value=0) / sku.annual_revenue.sum()
status = sku.groupby("status").agg(skus=("sku", "count"), stock_value=("stock_value", "sum"), excess=("excess_value", "sum"))
seg.to_csv(O / "abc_xyz_counts.csv"); segrev.to_csv(O / "abc_xyz_revenue_share.csv"); status.to_csv(O / "stock_health.csv")
print(seg, "\n", segrev.round(3), "\n", status.round(0))
print("A items:", (sku.ABC == "A").sum(), "share of SKUs", round((sku.ABC == "A").mean(), 3))
print("Excess stock R", round(sku.excess_value.sum()), " total stock R", round(sku.stock_value.sum()))

fig, ax = plt.subplots(figsize=(6.6, 3.6))
x = np.arange(1, N + 1) / N * 100
ax.plot(x, sku.cum_rev_pct * 100, color=PURPLE, lw=2.4)
ax.fill_between(x, sku.cum_rev_pct * 100, where=sku.ABC == "A", color=TEAL, alpha=0.25, label="A items")
ax.axhline(80, color=CORAL, ls="--", lw=1)
a_share = (sku.ABC == "A").mean() * 100
ax.axvline(a_share, color=CORAL, ls="--", lw=1)
ax.text(a_share + 1.5, 40, f"{a_share:.0f}% of SKUs\n= 80% of revenue", color=CORAL, fontsize=8.5)
ax.set_xlabel("% of SKUs (ranked by revenue)"); ax.set_ylabel("Cumulative revenue %")
ax.set_title("ABC Pareto curve")
save(fig, O / "chart_abc_pareto.png")

fig, ax = plt.subplots(figsize=(4.8, 3.6)); ax.grid(False)
im = ax.imshow(segrev.values * 100, cmap="GnBu")
for i in range(3):
    for j in range(3):
        ax.text(j, i, f"{seg.values[i, j]} SKUs\n{segrev.values[i, j]:.0%} rev", ha="center", va="center", fontsize=8,
                color="white" if segrev.values[i, j] > 0.2 else "#1E2632")
ax.set_xticks(range(3)); ax.set_xticklabels(["X stable", "Y variable", "Z erratic"]); ax.set_yticks(range(3)); ax.set_yticklabels(["A", "B", "C"])
ax.set_title("ABC-XYZ matrix (SKUs & revenue share)")
save(fig, O / "chart_abc_xyz_matrix.png")

fig, ax = plt.subplots(figsize=(5.6, 3.4))
order = ["Stock-out risk", "Reorder now", "Healthy", "Overstock"]
st = status.reindex(order)
b = ax.bar(order, st.skus, color=[CORAL, AMBER, TEAL, PURPLE])
ax.bar_label(b, padding=3, fontsize=8.5); ax.set_title("Stock health across 1,200 SKUs")
ax.tick_params(axis="x", labelsize=8.5)
save(fig, O / "chart_stock_health.png")
