"""IT Service Desk Performance Analysis (ITIL 4 lens) — applied IT service management project.

Generates 6 months of SYNTHETIC service-desk tickets for a 600-user logistics company,
measures SLA compliance, MTTR, first-contact resolution (FCR), backlog and CSAT,
and quantifies the business case for self-service password reset + a knowledge base.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, CORAL, AMBER, GREY  # noqa: E402

rng = np.random.default_rng(88)
D = ROOT / "data"; O = ROOT / "outputs"; D.mkdir(exist_ok=True); O.mkdir(exist_ok=True)
N = 5400
cats = {"Password / Access": (0.31, 0.6, 0.85), "Email & Office 365": (0.14, 3, 0.55), "Hardware": (0.12, 20, 0.2),
        "Network / VPN": (0.11, 6, 0.35), "Business Apps (ERP/WMS)": (0.16, 10, 0.3), "Printing & Scanners": (0.09, 4, 0.45),
        "Security Incident": (0.03, 5, 0.1), "New Starter / Leaver": (0.04, 24, 0.05)}
cat = rng.choice(list(cats), N, p=[v[0] for v in cats.values()])
prio = rng.choice(["P1", "P2", "P3", "P4"], N, p=[0.03, 0.14, 0.58, 0.25])
prio = np.where(cat == "Security Incident", rng.choice(["P1", "P2"], N, p=[0.4, 0.6]), prio)
sla_h = pd.Series(prio).map({"P1": 4, "P2": 8, "P3": 24, "P4": 72}).values
created = pd.to_datetime("2026-03-01") + pd.to_timedelta(rng.integers(0, 183 * 24 * 60, N), unit="m")
base = np.array([cats[c][1] for c in cat])
speed = pd.Series(prio).map({"P1": 0.35, "P2": 0.6, "P3": 1, "P4": 1.6}).values
res_h = np.round(rng.gamma(1.4, base * speed / 1.4) + 0.1, 2)
res_h = np.where(created.month >= 7, res_h * 0.82, res_h)          # knowledge base + triage change in July
fcr = rng.random(N) < np.array([cats[c][2] for c in cat]) * np.where(created.month >= 7, 1.15, 1)
channel = rng.choice(["Email", "Phone", "Portal", "Walk-up"], N, p=[0.42, 0.28, 0.22, 0.08])
csat = np.clip(np.round(rng.normal(4.3, 0.6, N) - np.where(res_h > sla_h, 1.1, 0) + np.where(fcr, 0.3, 0)), 1, 5)
t = pd.DataFrame({"ticket_id": [f"INC{100000 + i}" for i in range(N)], "created": created.strftime("%Y-%m-%d %H:%M"),
                  "month": created.strftime("%Y-%m"), "category": cat, "priority": prio, "channel": channel,
                  "sla_hours": sla_h, "resolution_hours": res_h, "sla_met": (res_h <= sla_h).astype(int),
                  "first_contact_resolved": fcr.astype(int), "csat": csat,
                  "agent": rng.choice([f"Agent {c}" for c in "ABCDEFG"], N)})
t.to_csv(D / "tickets.csv", index=False)

kpi = {"Tickets": len(t), "SLA met %": t.sla_met.mean(), "FCR %": t.first_contact_resolved.mean(),
       "Median resolution (h)": t.resolution_hours.median(), "CSAT": t.csat.mean()}
by_m = t.groupby("month").agg(tickets=("ticket_id", "count"), sla=("sla_met", "mean"), fcr=("first_contact_resolved", "mean"),
                              mttr=("resolution_hours", "median"), csat=("csat", "mean"))
by_c = t.groupby("category").agg(tickets=("ticket_id", "count"), sla=("sla_met", "mean"), mttr=("resolution_hours", "median")).sort_values("tickets", ascending=False)
by_c["cum_pct"] = by_c.tickets.cumsum() / by_c.tickets.sum()
by_p = t.groupby("priority").agg(tickets=("ticket_id", "count"), target_h=("sla_hours", "first"), sla=("sla_met", "mean"), mttr=("resolution_hours", "median"))
by_m.to_csv(O / "monthly_kpis.csv"); by_c.to_csv(O / "category_pareto.csv"); by_p.to_csv(O / "priority_sla.csv")
pd.Series(kpi).to_csv(O / "kpi_overview.csv")

# business case: self-service password reset (SSPR)
pw = t[t.category == "Password / Access"]
monthly_pw = len(pw) / 6
cost_per_ticket = 85                     # R, blended agent cost per ticket (assumption)
deflect = 0.65                           # share of password tickets SSPR can deflect (assumption)
saving = monthly_pw * deflect * cost_per_ticket * 12
hours_back = monthly_pw * deflect * 0.25 * 12
pd.DataFrame([{"password_tickets_per_month": round(monthly_pw), "deflection_assumption": deflect,
               "cost_per_ticket_zar": cost_per_ticket, "annual_saving_zar": round(saving), "agent_hours_released_per_year": round(hours_back)}]
             ).to_csv(O / "sspr_business_case.csv", index=False)
print(pd.Series(kpi)); print(by_m.round(3)); print(by_c.round(3)); print("SSPR saving R", round(saving), "hours", round(hours_back))

fig, ax = plt.subplots(figsize=(7, 3.5))
x = [m[5:] for m in by_m.index]
ax.bar(x, by_m.tickets, color="#DCEFF2", edgecolor=TEAL, label="Tickets")
ax2 = ax.twinx(); ax2.grid(False); ax2.spines["top"].set_visible(False)
ax2.plot(x, by_m.sla * 100, color=PURPLE, marker="o", lw=2.4, label="SLA met %")
ax2.plot(x, by_m.fcr * 100, color=AMBER, marker="s", lw=2, label="FCR %")
ax2.set_ylim(40, 100); ax2.legend(loc="lower right", fontsize=8.5)
ax.axvline(3.5, color=CORAL, ls="--", lw=1.1); ax.text(3.55, by_m.tickets.max() * 0.95, "KB + triage change", color=CORAL, fontsize=8)
ax.set_title("Service desk: SLA and first-contact resolution trend")
save(fig, O / "chart_sla_fcr_trend.png")

fig, ax = plt.subplots(figsize=(7, 3.5))
ax.bar(range(len(by_c)), by_c.tickets, color=[PURPLE if c <= 0.6 else TEAL2 for c in by_c.cum_pct])
ax.set_xticks(range(len(by_c))); ax.set_xticklabels([c.replace(" (ERP/WMS)", "") for c in by_c.index], rotation=25, ha="right", fontsize=8)
ax2 = ax.twinx(); ax2.grid(False); ax2.spines["top"].set_visible(False)
ax2.plot(range(len(by_c)), by_c.cum_pct * 100, color=CORAL, marker="o"); ax2.set_ylim(0, 105)
ax.set_title("Ticket Pareto: password/access is the #1 demand driver")
save(fig, O / "chart_category_pareto.png")

fig, ax = plt.subplots(figsize=(5.2, 3.3))
b = ax.bar(by_p.index, by_p.sla * 100, color=[CORAL, AMBER, TEAL, TEAL2])
ax.bar_label(b, labels=[f"{v:.0%}\n(target {int(h)}h)" for v, h in zip(by_p.sla, by_p.target_h)], fontsize=8, padding=2)
ax.set_ylim(0, 115); ax.set_title("SLA met % by priority")
save(fig, O / "chart_sla_by_priority.png")
