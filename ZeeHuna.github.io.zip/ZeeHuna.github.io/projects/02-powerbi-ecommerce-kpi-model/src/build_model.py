"""Build a Power BI-ready star schema (CSV) for an omnichannel e-commerce retailer,
validate every DAX measure in pandas, and render the model diagram + dashboard preview.

Data is SYNTHETIC (seeded) and modelled on South African online retail patterns.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parents[1] / "tools"))
from plotstyle import plt, save, TEAL, TEAL2, PURPLE, AMBER, CORAL, GREY, INK  # noqa: E402

rng = np.random.default_rng(11)
D = ROOT / "data"; O = ROOT / "outputs"
D.mkdir(exist_ok=True); O.mkdir(exist_ok=True)

# ---------------- dimensions ----------------
dates = pd.date_range("2025-01-01", "2026-06-30", freq="D")
dim_date = pd.DataFrame({"DateKey": dates.strftime("%Y%m%d").astype(int), "Date": dates, "Year": dates.year,
                         "Quarter": "Q" + dates.quarter.astype(str), "MonthNum": dates.month, "Month": dates.strftime("%b"),
                         "YearMonth": dates.strftime("%Y-%m"), "Weekday": dates.strftime("%a"),
                         "IsWeekend": dates.weekday >= 5})

cats = {"Fashion": (450, 0.14), "Beauty": (260, 0.05), "Home & Living": (780, 0.07), "Electronics": (2400, 0.06),
        "Food & Pantry": (320, 0.02), "Kids": (390, 0.09)}
prod = []
for i in range(240):
    cat = list(cats)[i % 6]
    price = round(cats[cat][0] * rng.uniform(0.4, 1.9), -1) - 1
    prod.append({"ProductKey": 1000 + i, "SKU": f"SKU-{1000 + i}", "Category": cat, "UnitPrice": price,
                 "UnitCost": round(price * rng.uniform(0.48, 0.66), 2), "ReturnRiskBase": cats[cat][1]})
dim_product = pd.DataFrame(prod)

provinces = ["Gauteng", "Western Cape", "KwaZulu-Natal", "Eastern Cape", "Free State", "Limpopo", "Mpumalanga", "North West", "Northern Cape"]
pw = np.array([0.38, 0.2, 0.15, 0.07, 0.05, 0.05, 0.05, 0.03, 0.02])
dim_customer = pd.DataFrame({"CustomerKey": range(1, 9001), "Province": rng.choice(provinces, 9000, p=pw),
                             "Segment": rng.choice(["New", "Returning", "Loyalty"], 9000, p=[0.35, 0.45, 0.2])})
dim_channel = pd.DataFrame({"ChannelKey": [1, 2, 3, 4], "Channel": ["Website", "Mobile App", "Marketplace", "Click & Collect"]})
dim_carrier = pd.DataFrame({"CarrierKey": [1, 2, 3, 4], "Carrier": ["Carrier A (Express)", "Carrier B (Economy)", "In-house Fleet", "Locker Network"],
                            "SLA_Days": [2, 4, 3, 3]})

# ---------------- fact ----------------
N = 62_000
day_idx = rng.integers(0, len(dates), N)
d = dates[day_idx]
season = 1 + 0.9 * ((d.month == 11) & (d.day >= 20)) + 0.4 * (d.month == 12) + 0.18 * (d.year == 2026)
keep = rng.random(N) < season / season.max()
d = d[keep]; n = len(d)
pk = rng.choice(dim_product["ProductKey"], n)
p = dim_product.set_index("ProductKey").loc[pk]
qty = rng.choice([1, 1, 1, 2, 2, 3], n)
disc = np.where((d.month == 11) & (d.day >= 20), rng.uniform(0.15, 0.35, n), rng.choice([0, 0, 0, 0.1], n))
car = rng.choice([1, 2, 3, 4], n, p=[0.35, 0.3, 0.2, 0.15])
sla = dim_carrier.set_index("CarrierKey").loc[car, "SLA_Days"].values
peak = ((d.month == 11) & (d.day >= 20)) | (d.month == 12)
deliver = sla + rng.choice([-1, -1, 0, 0, 0, 0, 0, 0, 1, 2], n) + np.where(peak, rng.choice([0, 0, 0, 1], n), 0) + np.where(car == 3, rng.choice([0, 0, 1], n), 0) - np.where(car == 4, rng.random(n) < 0.12, 0) - np.where(d.year == 2026, rng.random(n) < 0.3, 0)
deliver = np.maximum(deliver, 1)
fact = pd.DataFrame({
    "OrderLineID": range(1, n + 1), "OrderDateKey": d.strftime("%Y%m%d").astype(int), "ProductKey": pk,
    "CustomerKey": rng.integers(1, 9001, n), "ChannelKey": rng.choice([1, 2, 3, 4], n, p=[0.42, 0.33, 0.15, 0.10]),
    "CarrierKey": car, "Quantity": qty, "UnitPrice": p["UnitPrice"].values, "DiscountPct": np.round(disc, 2),
    "UnitCost": p["UnitCost"].values, "DeliveryDays": deliver, "SLA_Days": sla,
    "Returned": (rng.random(n) < p["ReturnRiskBase"].values * np.where(deliver > sla, 1.8, 1)).astype(int),
    "Cancelled": (rng.random(n) < 0.015).astype(int),
})
fact["NetSales"] = np.round(fact["Quantity"] * fact["UnitPrice"] * (1 - fact["DiscountPct"]), 2)
fact["COGS"] = np.round(fact["Quantity"] * fact["UnitCost"], 2)

for name, t in [("dim_date", dim_date), ("dim_product", dim_product), ("dim_customer", dim_customer),
                ("dim_channel", dim_channel), ("dim_carrier", dim_carrier), ("fact_order_lines", fact)]:
    t.to_csv(D / f"{name}.csv", index=False)

# ---------------- validate DAX measures in pandas ----------------
f = fact.merge(dim_date[["DateKey", "Year", "YearMonth"]], left_on="OrderDateKey", right_on="DateKey")
valid = f[f.Cancelled == 0]
def measures(x):
    rev = x.NetSales.sum(); gp = rev - x.COGS.sum()
    return {"Net Revenue (R)": rev, "Orders": len(x), "Avg Order Value (R)": rev / len(x), "Gross Margin %": gp / rev,
            "On-Time Delivery %": (x.DeliveryDays <= x.SLA_Days).mean(), "Return Rate %": x.Returned.mean(),
            "Perfect Order %": ((x.DeliveryDays <= x.SLA_Days) & (x.Returned == 0)).mean(),
            "Avg Delivery Days": x.DeliveryDays.mean()}
h1_25 = valid[(valid.Year == 2025) & (valid.YearMonth <= "2025-06")]
h1_26 = valid[valid.Year == 2026]
val = pd.DataFrame({"H1 2025": measures(h1_25), "H1 2026": measures(h1_26)})
val["Change"] = val["H1 2026"] - val["H1 2025"]
val.to_csv(O / "measure_validation_h1.csv")
print(val)

monthly = valid.groupby("YearMonth").apply(lambda x: pd.Series(measures(x)), include_groups=False)
monthly.to_csv(O / "monthly_kpis.csv")
cat_tbl = valid.merge(dim_product[["ProductKey", "Category"]], on="ProductKey").groupby("Category").apply(
    lambda x: pd.Series({"Net Revenue (R)": x.NetSales.sum(), "Gross Margin %": 1 - x.COGS.sum() / x.NetSales.sum(),
                         "Return Rate %": x.Returned.mean()}), include_groups=False).sort_values("Net Revenue (R)", ascending=False)
cat_tbl.to_csv(O / "category_kpis.csv")
car_tbl = valid.merge(dim_carrier[["CarrierKey", "Carrier"]], on="CarrierKey").groupby("Carrier").apply(
    lambda x: pd.Series({"On-Time %": (x.DeliveryDays <= x.SLA_Days).mean(), "Avg Days": x.DeliveryDays.mean(), "Lines": len(x)}), include_groups=False)
car_tbl.to_csv(O / "carrier_kpis.csv")
prov_tbl = valid.merge(dim_customer, on="CustomerKey").groupby("Province").NetSales.sum().sort_values(ascending=False)

# ---------------- model diagram ----------------
fig, ax = plt.subplots(figsize=(8, 5)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 7)
def box(x, y, title, fields, color):
    h = 0.42 + 0.3 * len(fields)
    ax.add_patch(plt.Rectangle((x, y - h), 2.6, h, facecolor="white", edgecolor=color, lw=2))
    ax.add_patch(plt.Rectangle((x, y - 0.42), 2.6, 0.42, facecolor=color, edgecolor=color))
    ax.text(x + 0.12, y - 0.3, title, color="white", fontweight="bold", fontsize=9.5)
    for i, fl in enumerate(fields):
        ax.text(x + 0.14, y - 0.66 - 0.3 * i, fl, fontsize=8, color=INK)
    return (x + 1.3, y - h / 2)
fc = box(3.7, 5.2, "fact_order_lines", ["OrderDateKey (FK)", "ProductKey (FK)", "CustomerKey (FK)", "ChannelKey (FK)", "CarrierKey (FK)",
                                         "Quantity · NetSales · COGS", "DeliveryDays · SLA_Days", "Returned · Cancelled"], PURPLE)
dims = [(0.2, 6.6, "dim_date", ["DateKey (PK)", "Year · Quarter · Month", "IsWeekend"]),
        (0.2, 3.0, "dim_product", ["ProductKey (PK)", "Category · SKU", "UnitPrice · UnitCost"]),
        (7.2, 6.6, "dim_customer", ["CustomerKey (PK)", "Province", "Segment"]),
        (7.2, 3.9, "dim_channel", ["ChannelKey (PK)", "Channel"]),
        (7.2, 1.9, "dim_carrier", ["CarrierKey (PK)", "Carrier · SLA_Days"])]
for x, y, t, fl in dims:
    c = box(x, y, t, fl, TEAL)
    ax.annotate("", xy=(fc[0] + (-1.3 if x < 3 else 1.3), fc[1]), xytext=(c[0] + (1.3 if x < 3 else -1.3), c[1]),
                arrowprops=dict(arrowstyle="-", color=GREY, lw=1.4))
    ax.text(c[0] + (1.38 if x < 3 else -1.55), c[1] + 0.08, "1", fontsize=8, color=GREY)
ax.text(fc[0] + (-1.55), fc[1] + 0.12, "*", fontsize=11, color=GREY); ax.text(fc[0] + 1.38, fc[1] + 0.12, "*", fontsize=11, color=GREY)
ax.set_title("Star schema: 1 fact table, 5 dimensions (one-to-many, single direction)")
save(fig, O / "model_diagram.png")

# ---------------- dashboard preview ----------------
fig = plt.figure(figsize=(12, 6.8)); fig.patch.set_facecolor("#F4F7F9")
gs = fig.add_gridspec(3, 4, height_ratios=[0.55, 1.5, 1.5], hspace=0.55, wspace=0.55, left=0.1, right=0.98, top=0.9, bottom=0.06)
k = val["H1 2026"]; ch = val["Change"]
tiles = [("Net Revenue", f"R{k['Net Revenue (R)']/1e6:.1f}M", f"{ch['Net Revenue (R)']/val.loc['Net Revenue (R)','H1 2025']:+.0%} YoY"),
         ("Gross Margin", f"{k['Gross Margin %']:.1%}", f"{ch['Gross Margin %']*100:+.1f} pts"),
         ("On-Time Delivery", f"{k['On-Time Delivery %']:.1%}", f"{ch['On-Time Delivery %']*100:+.1f} pts"),
         ("Perfect Order", f"{k['Perfect Order %']:.1%}", f"{ch['Perfect Order %']*100:+.1f} pts")]
for i, (t, v, s) in enumerate(tiles):
    a = fig.add_subplot(gs[0, i]); a.axis("off")
    a.add_patch(plt.Rectangle((0, 0), 1, 1, transform=a.transAxes, facecolor="white", edgecolor="#DDE3E8"))
    a.text(0.06, 0.72, t, fontsize=9, color=GREY, transform=a.transAxes)
    a.text(0.06, 0.28, v, fontsize=17, fontweight="bold", color=PURPLE if i % 2 else TEAL, transform=a.transAxes)
    a.text(0.94, 0.72, s, fontsize=8.5, ha="right", color="#1B998B" if "+" in s else CORAL, transform=a.transAxes)
a = fig.add_subplot(gs[1, :2]); mm = monthly["Net Revenue (R)"] / 1e6
a.fill_between(range(len(mm)), mm.values, color=TEAL2, alpha=0.25); a.plot(range(len(mm)), mm.values, color=TEAL, lw=2.2)
a.set_xticks(range(0, len(mm), 3)); a.set_xticklabels(mm.index[::3], fontsize=8); a.set_title("Net revenue by month (R m) — Black Friday peak visible")
a = fig.add_subplot(gs[1, 2:]); ct = cat_tbl["Net Revenue (R)"] / 1e6
a.barh(ct.index[::-1], ct.values[::-1], color=PURPLE); a.set_title("Revenue by category (R m)")
a = fig.add_subplot(gs[2, :2]); ot = monthly["On-Time Delivery %"] * 100
a.plot(range(len(ot)), ot.values, color=PURPLE, marker="o", ms=3); a.axhline(80, color=CORAL, ls="--", lw=1); a.text(0, 80.6, "Target 80%", color=CORAL, fontsize=8)
a.set_xticks(range(0, len(ot), 3)); a.set_xticklabels(ot.index[::3], fontsize=8); a.set_title("On-time delivery % by month")
a = fig.add_subplot(gs[2, 2]); cr = car_tbl["On-Time %"] * 100
a.bar([{"Carrier A (Express)": "Express", "Carrier B (Economy)": "Economy", "In-house Fleet": "Fleet", "Locker Network": "Lockers"}[c] for c in cr.index], cr.values, color=[TEAL, TEAL2, PURPLE, AMBER]); a.set_ylim(50, 100)
a.set_title("On-time % by carrier"); a.tick_params(axis="x", labelsize=7.5)
a = fig.add_subplot(gs[2, 3]); pv = prov_tbl.head(5) / 1e6
a.barh([p_.replace("KwaZulu-Natal", "KZN") for p_ in pv.index[::-1]], pv.values[::-1], color=TEAL); a.set_title("Top provinces (R m)")
fig.suptitle("E-commerce Operations Performance — Power BI report page preview", x=0.02, ha="left", fontsize=14, fontweight="bold", color=INK)
fig.savefig(O / "dashboard_preview.png", dpi=170); plt.close(fig)
print("done")
